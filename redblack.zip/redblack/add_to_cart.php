<?php
require_once 'config.php';

header('Content-Type: application/json');

if(!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Необходимо авторизоваться']);
    exit();
}

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $item_id = (int)$_POST['item_id'];
    
    if(!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    if(isset($_SESSION['cart'][$item_id])) {
        $_SESSION['cart'][$item_id]++;
    } else {
        $_SESSION['cart'][$item_id] = 1;
    }
    
    // Подсчет общего количества товаров в корзине
    $cartCount = array_sum($_SESSION['cart']);
    
    echo json_encode(['success' => true, 'cartCount' => $cartCount, 'count' => $cartCount]);
} else {
    echo json_encode(['success' => false, 'message' => 'Некорректный запрос']);
}
?>