<?php
require_once 'config.php';
checkRole('admin');

// Обработка добавления менеджера
if(isset($_POST['add_manager'])) {
    $username = sanitize($_POST['username']);
    $email = sanitize($_POST['email']);
    $password = sanitize($_POST['password']);
    
    try {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, 'manager')");
        $stmt->execute([$username, $hashed_password, $email]);
        $success = "Менеджер успешно добавлен";
    } catch(PDOException $e) {
        $error = "Ошибка при добавлении менеджера: " . $e->getMessage();
    }
}

// Обработка удаления пользователя
if(isset($_GET['delete_user'])) {
    $user_id = (int)$_GET['delete_user'];
    
    try {
        $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role != 'admin'");
        $stmt->execute([$user_id]);
        $success = "Пользователь успешно удален";
    } catch(PDOException $e) {
        $error = "Ошибка при удалении пользователя: " . $e->getMessage();
    }
}

// Обработка добавления категории
if(isset($_POST['add_category'])) {
    $name = sanitize($_POST['name']);
    $description = sanitize($_POST['description']);
    
    try {
        $stmt = $pdo->prepare("INSERT INTO categories (name, description) VALUES (?, ?)");
        $stmt->execute([$name, $description]);
        $success = "Категория успешно добавлена";
    } catch(PDOException $e) {
        $error = "Ошибка при добавлении категории: " . $e->getMessage();
    }
}

// Обработка добавления блюда
if(isset($_POST['add_menu_item'])) {
    $name = sanitize($_POST['name']);
    $description = sanitize($_POST['description']);
    $price = (float)$_POST['price'];
    $category_id = (int)$_POST['category_id'];
    
    // Обработка загрузки изображения
    $image_path = '';
    if(isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $upload_dir = 'images/menu/';
        if(!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_name = uniqid() . '_' . basename($_FILES['image']['name']);
        $target_path = $upload_dir . $file_name;
        
        if(move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
            $image_path = $target_path;
        }
    }
    
    try {
        $stmt = $pdo->prepare("INSERT INTO menu_items (name, description, price, category_id, image_path) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$name, $description, $price, $category_id, $image_path]);
        $success = "Блюдо успешно добавлено";
    } catch(PDOException $e) {
        $error = "Ошибка при добавлении блюда: " . $e->getMessage();
    }
}

// Получаем список менеджеров
$managers = [];
try {
    $stmt = $pdo->query("SELECT * FROM users WHERE role = 'manager'");
    $managers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $error = "Ошибка при получении списка менеджеров: " . $e->getMessage();
}

// Получаем список категорий
$categories = [];
try {
    $stmt = $pdo->query("SELECT * FROM categories");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $error = "Ошибка при получении категорий: " . $e->getMessage();
}

// Получаем список блюд
$menuItems = [];
try {
    $stmt = $pdo->query("SELECT m.*, c.name as category_name FROM menu_items m LEFT JOIN categories c ON m.category_id = c.id");
    $menuItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $error = "Ошибка при получении меню: " . $e->getMessage();
}

// Обработка изменения доступности блюда
if(isset($_POST['toggle_availability'])) {
    $menu_item_id = (int)$_POST['menu_item_id'];
    $is_available = $_POST['is_available'] == '1' ? 1 : 0;

    try {
        $stmt = $pdo->prepare("UPDATE menu_items SET is_available = ? WHERE id = ?");
        $stmt->execute([$is_available, $menu_item_id]);
        $success = "Статус блюда обновлен";
    } catch(PDOException $e) {
        $error = "Ошибка при обновлении доступности: " . $e->getMessage();
    }
}
?>



<!DOCTYPE html>
<html lang="ru">
<head>
<meta property="og:title" content="Red&Black Cafe">
<meta property="og:type" content="website">
<meta property="og:image" content="images/favicon.svg">

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#cc0000">
<meta name="description" content="Red&Black Cafe — онлайн-меню, быстрая корзина и оформление заказа.">
<link rel="icon" href="images/favicon.svg" type="image/svg+xml">
<link rel="manifest" href="site.webmanifest">
<link rel="preload" as="style" href="css/style.css" onload="this.onload=null;this.rel='stylesheet'">
<noscript><link rel="stylesheet" href="css/style.css"></noscript>
<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" referrerpolicy="no-referrer">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Админ-панель - Red&Black Cafe</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/main.js" defer></script>
</head>
<body>
    <header>
        <div class="container header-content">
            <div class="logo">Red<span>&</span>Black</div>
            <nav>
    <ul>
        <?php if(!isManagerOrAdmin()): ?>

        <?php endif; ?>
        <?php if(isLoggedIn()): ?>
            <?php if(userHasRole(['admin'])): ?>
                <li><a href="admin.php"><i class="fa-solid fa-user-gear" aria-hidden="true"></i> <span>Админ-панель</span></a></li>
            <?php elseif(userHasRole(['manager'])): ?>
                <li><a href="manager.php"><i class="fa-solid fa-clipboard-list" aria-hidden="true"></i> <span>Менеджер</span></a></li>
            <?php else: ?>
                <li><a href="orders.php"><i class="fa-solid fa-receipt" aria-hidden="true"></i> <span>Мои заказы</span></a></li>
            <?php endif; ?>
            <li><a href="logout.php"><i class="fa-solid fa-right-from-bracket" aria-hidden="true"></i> <span>Выйти</span></a></li>
        <?php else: ?>
            <li><a href="login.php"><i class="fa-solid fa-right-to-bracket" aria-hidden="true"></i> <span>Войти</span></a></li>
            <li><a href="register.php"><i class="fa-solid fa-user-plus" aria-hidden="true"></i> <span>Регистрация</span></a></li>
        <?php endif; ?>
    </ul>
</nav>
        </div>
    </header>

    <main class="container">
        <h1>Админ-панель</h1>
        
        <?php if(isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if(isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <div class="admin-panel">
            <div class="admin-sidebar">
                <ul>
                    <li><a href="#managers">Управление менеджерами</a></li>
                    <li><a href="#categories">Управление категориями</a></li>
                    <li><a href="#menu">Управление меню</a></li>
                </ul>
            </div>
            
            <div class="admin-content">
                <section id="managers">
                    <h2>Добавить менеджера</h2>
                    <form action="admin.php" method="POST">
                        <div class="form-group">
                            <label for="username">Имя пользователя</label>
                            <input type="text" id="username" name="username" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Пароль</label>
                            <input type="password" id="password" name="password" required>
                        </div>
                        <button type="submit" name="add_manager" class="btn btn-block">Добавить менеджера</button>
                    </form>
                    
                    <h2 style="margin-top: 30px;">Список менеджеров</h2>
                    <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                        <thead>
                            <tr style="background-color: var(--primary-red); color: white;">
                                <th style="padding: 10px; text-align: left;">ID</th>
                                <th style="padding: 10px; text-align: left;">Имя пользователя</th>
                                <th style="padding: 10px; text-align: left;">Email</th>
                                <th style="padding: 10px; text-align: left;">Действия</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($managers as $manager): ?>
                                <tr style="border-bottom: 1px solid var(--dark-gray);">
                                    <td style="padding: 10px;"><?php echo $manager['id']; ?></td>
                                    <td style="padding: 10px;"><?php echo $manager['username']; ?></td>
                                    <td style="padding: 10px;"><?php echo $manager['email']; ?></td>
                                    <td style="padding: 10px;">
                                        <a href="admin.php?delete_user=<?php echo $manager['id']; ?>" class="btn" style="background-color: var(--dark-gray);" onclick="return confirm('Вы уверены?')">Удалить</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </section>
                
                <section id="categories" style="margin-top: 50px;">
                    <h2>Добавить категорию</h2>
                    <form action="admin.php" method="POST">
                        <div class="form-group">
                            <label for="name">Название категории</label>
                            <input type="text" id="name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="description">Описание</label>
                            <textarea id="description" name="description" rows="3"></textarea>
                        </div>
                        <button type="submit" name="add_category" class="btn btn-block">Добавить категорию</button>
                    </form>
                    
                    <h2 style="margin-top: 30px;">Список категорий</h2>
                    <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                        <thead>
                            <tr style="background-color: var(--primary-red); color: white;">
                                <th style="padding: 10px; text-align: left;">ID</th>
                                <th style="padding: 10px; text-align: left;">Название</th>
                                <th style="padding: 10px; text-align: left;">Описание</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($categories as $category): ?>
                                <tr style="border-bottom: 1px solid var(--dark-gray);">
                                    <td style="padding: 10px;"><?php echo $category['id']; ?></td>
                                    <td style="padding: 10px;"><?php echo $category['name']; ?></td>
                                    <td style="padding: 10px;"><?php echo $category['description']; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </section>
                
                <section id="menu" style="margin-top: 50px;">
                    <h2>Добавить блюдо</h2>
                    <form action="admin.php" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="name">Название блюда</label>
                            <input type="text" id="name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="description">Описание</label>
                            <textarea id="description" name="description" rows="3"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="price">Цена</label>
                            <input type="number" id="price" name="price" step="0.01" min="0" required>
                        </div>
                        <div class="form-group">
                            <label for="category_id">Категория</label>
                            <select id="category_id" name="category_id" required>
                                <option value="">Выберите категорию</option>
                                <?php foreach($categories as $category): ?>
                                    <option value="<?php echo $category['id']; ?>"><?php echo $category['name']; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="image">Изображение</label>
                            <input type="file" id="image" name="image">
                        </div>
                        <button type="submit" name="add_menu_item" class="btn btn-block">Добавить блюдо</button>
                    </form>
                    
                    <h2 style="margin-top: 30px;">Список блюд</h2>
                    <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                        <thead>
                            <tr style="background-color: var(--primary-red); color: white;">
                                <th style="padding: 10px; text-align: left;">ID</th>
                                <th style="padding: 10px; text-align: left;">Название</th>
                                <th style="padding: 10px; text-align: left;">Категория</th>
                                <th style="padding: 10px; text-align: left;">Цена</th>
                                <th style="padding: 10px; text-align: left;">Доступно</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($menuItems as $item): ?>
                                <tr style="border-bottom: 1px solid var(--dark-gray);">
                                    <td style="padding: 10px;"><?php echo $item['id']; ?></td>
                                    <td style="padding: 10px;"><?php echo $item['name']; ?></td>
                                    <td style="padding: 10px;"><?php echo $item['category_name'] ?? 'Без категории'; ?></td>
                                    <td style="padding: 10px;"><?php echo $item['price']; ?> ₽</td>
                                    <td style="padding: 10px;">
    <form method="POST" style="display:inline;">
        <input type="hidden" name="menu_item_id" value="<?php echo $item['id']; ?>">
        <select name="is_available" onchange="this.form.submit()">
            <option value="1" <?php echo $item['is_available'] ? 'selected' : ''; ?>>Да</option>
            <option value="0" <?php echo !$item['is_available'] ? 'selected' : ''; ?>>Нет</option>
        </select>
        <input type="hidden" name="toggle_availability" value="1">
    </form>
</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </section>
            </div>
        </div>
    <?php include 'footer.php'; ?>