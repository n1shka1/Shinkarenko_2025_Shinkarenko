<?php
session_start();

// Настройки базы данных
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'redblack_cafe');

// Подключение к базе данных
try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Ошибка подключения к базе данных: " . $e->getMessage());
}

// Функция для проверки авторизации
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Функция для проверки роли пользователя
function checkRole($requiredRole) {
    if (!isLoggedIn() || $_SESSION['user_role'] != $requiredRole) {
        header("Location: login.php");
        exit();
    }
}

// Функция для защиты от XSS
function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}


// Проверка: менеджер или администратор
function isManagerOrAdmin() {
    return isLoggedIn() && (isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['manager','admin']));
}

// Проверка роли из набора
function userHasRole($roles = []) {
    return isLoggedIn() && isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], $roles);
}


?>
