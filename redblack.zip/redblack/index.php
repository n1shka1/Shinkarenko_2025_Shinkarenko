<?php
require_once 'config.php';

/* RB: role redirect */
if (isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['admin','manager'])) {
    $dest = ($_SESSION['user_role'] === 'admin') ? 'admin.php' : 'manager.php';
    header("Location: " . $dest);
    exit();
}

// Получаем список категорий
$categories = [];
try {
    $stmt = $pdo->query("SELECT * FROM categories");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $error = "Ошибка при получении категорий: " . $e->getMessage();
}

// Получаем случайные 3 доступных блюда
$popular = [];
try {
    $stp = $pdo->query("SELECT * FROM menu_items WHERE is_available = 1 ORDER BY RAND() LIMIT 3");
    $popular = $stp->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $error = "Ошибка при получении меню: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
<meta property="og:title" content="Red&Black Cafe">
<meta property="og:type" content="website">
<meta property="og:image" content="images/favicon.svg">

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#cc0000">
<meta name="description" content="Red&Black Cafe — онлайн-меню, быстрая корзина и оформление заказа.">
<link rel="icon" href="images/favicon.svg" type="image/svg+xml">
<link rel="manifest" href="site.webmanifest">
<link rel="preload" as="style" href="css/style.css" onload="this.onload=null;this.rel='stylesheet'">
<noscript><link rel="stylesheet" href="css/style.css"></noscript>
<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" referrerpolicy="no-referrer">

<title>Red&Black Cafe</title>
<link rel="stylesheet" href="css/style.css">
<script src="js/main.js" defer></script>
</head>
<body>
    <header>
        <div class="container header-content">
            <div class="logo">Red<span>&</span>Black</div>
            <?php if (isLoggedIn()): ?>
                <div class="user-greeting">Привет, <?= htmlspecialchars($_SESSION['username']) ?>!</div>
            <?php endif; ?>
            <nav>
                <ul>
                    <li><a href="index.php"><i class="fa-solid fa-house" aria-hidden="true"></i> <span>Главная</span></a></li>
                    <?php if (!isManagerOrAdmin()): ?>
                        <li><a href="menu.php"><i class="fa-solid fa-utensils" aria-hidden="true"></i> <span>Меню</span></a></li>
                    <?php endif; ?>
                    <?php if (isLoggedIn()): ?>
                        <?php if (userHasRole(['admin'])): ?>
                            <li><a href="admin.php"><i class="fa-solid fa-user-gear" aria-hidden="true"></i> <span>Админ-панель</span></a></li>
                        <?php elseif (userHasRole(['manager'])): ?>
                            <li><a href="manager.php"><i class="fa-solid fa-clipboard-list" aria-hidden="true"></i> <span>Менеджер</span></a></li>
                        <?php else: ?>
                            <li><a href="orders.php"><i class="fa-solid fa-receipt" aria-hidden="true"></i> <span>Мои заказы</span></a></li>
                        <?php endif; ?>
                        <li><a href="cart.php"><i class="fa-solid fa-cart-shopping" aria-hidden="true"></i> <span>Корзина</span> <span class="cart-count">0</span></a></li>
                        <li><a href="logout.php"><i class="fa-solid fa-right-from-bracket" aria-hidden="true"></i> <span>Выйти</span></a></li>
                    <?php else: ?>
                        <li><a href="login.php"><i class="fa-solid fa-right-to-bracket" aria-hidden="true"></i> <span>Войти</span></a></li>
                        <li><a href="register.php"><i class="fa-solid fa-user-plus" aria-hidden="true"></i> <span>Регистрация</span></a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <section>
            <h1>Добро пожаловать в Red&Black Cafe</h1>
            <p>Откройте для себя неповторимый вкус наших блюд и напитков в стильной атмосфере.</p>
            
            <?php if (isset($error)): ?>
                <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
        </section>

        <section>
            <h2>Популярные блюда</h2>
            <div class="menu-grid">
                <?php foreach ($popular as $item): ?>
                    <div class="menu-item">
                        <img src="<?= $item['image_path'] ?: 'images/placeholder.jpg'; ?>" 
                             alt="<?= htmlspecialchars($item['name']); ?>" 
                             class="menu-item-img">
                        <div class="menu-item-content">
                            <h3 class="menu-item-title"><?= htmlspecialchars($item['name']); ?></h3>
                            <p class="menu-item-desc"><?= htmlspecialchars($item['description']); ?></p>
                            <div class="menu-item-footer">
                                <span class="menu-item-price"><?= $item['price']; ?> ₽</span>
                                <?php if (isLoggedIn()): ?>
                                    <button class="btn add-to-cart" data-id="<?= $item['id']; ?>">В корзину</button>
                                <?php else: ?>
                                    <a href="login.php" class="btn">Войдите для заказа</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div style="text-align: center; margin-top: 20px;">
                <a href="menu.php" class="btn">Посмотреть полное меню</a>
            </div>
        </section>
    </main>

    <?php include 'footer.php'; ?>
</body>
</html>
