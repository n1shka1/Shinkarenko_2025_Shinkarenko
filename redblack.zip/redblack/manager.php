<?php
require_once 'config.php';

// Доступ только менеджеру и администратору
if (!userHasRole(['manager', 'admin'])) {
    header("Location: login.php");
    exit();
}

// Фильтр заказов
$filter = $_GET['filter'] ?? 'active';
if ($filter === 'inactive') {
    $statusCondition = "o.status IN ('delivered','cancelled','paid')";
} else {
    $statusCondition = "o.status NOT IN ('delivered','cancelled','paid')";
}

// Обработка изменения статуса заказа
if(isset($_POST['update_status'])) {
    $order_id = (int)$_POST['order_id'];
    $status = sanitize($_POST['status']);
    
    try {
        // Получим старый статус
        $stmtOld = $pdo->prepare("SELECT status FROM orders WHERE id = ?");
        $stmtOld->execute([$order_id]);
        $old_status = $stmtOld->fetchColumn();

        // Обновим заказ
        $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->execute([$status, $order_id]);

        // Запишем лог
        $changed_by = $_SESSION['user_id'] ?? null;
        $stmtLog = $pdo->prepare("INSERT INTO order_status_log (order_id, old_status, new_status, changed_by) VALUES (?, ?, ?, ?)");
        $stmtLog->execute([$order_id, $old_status, $status, $changed_by]);

        $success = "Статус заказа успешно обновлен";
    } catch(PDOException $e) {
        $error = "Ошибка при обновлении статуса: " . $e->getMessage();
    }
}

// Получаем список заказов
$orders = [];
try {
    $stmt = $pdo->prepare("
        SELECT o.*, u.username 
        FROM orders o 
        JOIN users u ON o.user_id = u.id 
        WHERE $statusCondition 
        ORDER BY o.order_date DESC
    ");
    $stmt->execute();
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    foreach($orders as &$order) {
        $stmtItems = $pdo->prepare("
            SELECT oi.*, mi.name 
            FROM order_items oi 
            JOIN menu_items mi ON oi.menu_item_id = mi.id 
            WHERE oi.order_id = ?
        ");
        $stmtItems->execute([$order['id']]);
        $order['items'] = $stmtItems->fetchAll(PDO::FETCH_ASSOC);
    }
    unset($order);

} catch(PDOException $e) {
    $error = "Ошибка при получении заказов: " . $e->getMessage();
}
?>
<!DOCTYPE html> 
<html lang="ru"> 
<head> 
<meta property="og:title" content="Red&Black Cafe"> 
<meta property="og:type" content="website"> 
<meta property="og:image" content="images/favicon.svg"> 
<meta charset="utf-8"> 
<meta name="viewport" content="width=device-width, initial-scale=1"> 
<meta name="theme-color" content="#cc0000">
<meta name="description" content="Red&Black Cafe — онлайн-меню, быстрая корзина и оформление заказа."> 
<link rel="icon" href="images/favicon.svg" type="image/svg+xml"> 
<link rel="manifest" href="site.webmanifest"> 
<link rel="preload" as="style" href="css/style.css" onload="this.onload=null;this.rel='stylesheet'"><noscript>
<link rel="stylesheet" href="css/style.css"></noscript> 
<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" referrerpolicy="no-referrer"> 
<title>Панель менеджера - Red&Black Cafe</title> 
<link rel="stylesheet" href="css/style.css"> <script src="js/main.js" defer></script> </head> <body> <?php include 'header.php'; ?> <main class="container">
    <h1>Панель менеджера</h1>

    <div class="orders-nav" style="margin-bottom: 20px;">
        <a href="manager.php?filter=active" class="<?= $filter === 'active' ? 'active' : '' ?>">Активные</a> |
        <a href="manager.php?filter=inactive" class="<?= $filter === 'inactive' ? 'active' : '' ?>">Неактивные</a>
    </div>

    <?php if(isset($error)): ?>
        <div class="alert alert-error"><?= $error; ?></div>
    <?php endif; ?>
    
    <?php if(isset($success)): ?>
        <div class="alert alert-success"><?= $success; ?></div>
    <?php endif; ?>

    <?php if(empty($orders)): ?>
        <p>Нет заказов для отображения.</p>
    <?php else: ?>
        <div style="margin-top: 30px;">
            <?php foreach($orders as $order): ?>
                <div style="background-color: var(--dark-gray); padding: 20px; border-radius: 5px; margin-bottom: 20px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                        <div>
                            <h3>Заказ #<?= $order['id']; ?></h3>
                            <p>Клиент: <?= $order['username']; ?></p>
                            <p>Дата: <?= $order['order_date']; ?></p>
                            <p>Адрес: <?= $order['delivery_address']; ?></p>
                            <p>Телефон: <?= $order['phone']; ?></p>
                        </div>
                        <div>
                            <form action="manager.php" method="POST">
                                <input type="hidden" name="order_id" value="<?= $order['id']; ?>">
                                <input type="hidden" name="update_status" value="0">
                                <div class="form-group">
                                    <label for="status">Статус</label>
                                    <select name="status" id="status" onchange="this.form.querySelector('input[name=\'update_status\']').value=1; this.form.submit()">
                                        <option value="pending" <?= $order['status'] == 'pending' ? 'selected' : ''; ?>>Принят</option>
                                        <option value="preparing" <?= $order['status'] == 'preparing' ? 'selected' : ''; ?>>Готовится</option>
                                        <option value="out_for_delivery" <?= $order['status'] == 'out_for_delivery' ? 'selected' : ''; ?>>Передан курьеру</option>
                                        <option value="delivered" <?= $order['status'] == 'delivered' ? 'selected' : ''; ?>>Доставлен</option>
                                        <option value="paid" <?= $order['status'] == 'paid' ? 'selected' : ''; ?>>Оплачен</option>
                                        <option value="cancelled" <?= $order['status'] == 'cancelled' ? 'selected' : ''; ?>>Отменен</option>
                                    </select>
                                </div>
                                <button type="submit" name="update_status" style="display: none;">Обновить</button>
                            </form>
                            <p style="margin-top: 10px; font-weight: bold;">Сумма: <?= $order['total_amount']; ?> ₽</p>
                        </div>
                    </div>
                    <h4>Состав заказа:</h4>
                    <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                        <thead>
                            <tr style="background-color: var(--black);">
                                <th style="padding: 10px; text-align: left;">Блюдо</th>
                                <th style="padding: 10px; text-align: left;">Количество</th>
                                <th style="padding: 10px; text-align: left;">Цена</th>
                                <th style="padding: 10px; text-align: left;">Сумма</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($order['items'] as $item): ?>
                                <tr style="border-bottom: 1px solid var(--black);">
                                    <td style="padding: 10px;"><?= $item['name']; ?></td>
                                    <td style="padding: 10px;"><?= $item['quantity']; ?></td>
                                    <td style="padding: 10px;"><?= $item['price']; ?> ₽</td>
                                    <td style="padding: 10px;"><?= $item['price'] * $item['quantity']; ?> ₽</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>

<?php include 'footer.php'; ?>
</body>
</html>
