// main.js — cart handling and UI helpers
(function () {
  'use strict';

  function qs(sel, ctx) { return (ctx || document).querySelector(sel); }
  function qsa(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }

  function updateCartCountDisplay(count) {
    try {
      var badge = qs('[data-cart-count]') || qs('#cart-count') || qs('.cart-count');
      if(!badge) return;
      badge.textContent = String(count || 0);
      badge.style.display = (parseInt(count,10) > 0) ? 'inline-block' : 'none';
    } catch (e) { console.error('updateCartCountDisplay', e); }
  }

  function safeJson(res) {
    return res.text().then(function(text) {
      try { return JSON.parse(text); } catch(e){ return null; }
    });
  }

  function fetchCartCount() {
    return fetch('get_cart_count.php', { credentials: 'same-origin', headers: { 'X-Requested-With': 'XMLHttpRequest' } })
      .then(function(r){ return safeJson(r); })
      .then(function(data){ if(data && data.success) updateCartCountDisplay(data.count); })
      .catch(function(){ /* silent */ });
  }

  function addToCartRequest(itemId) {
    var body = new URLSearchParams();
    body.set('item_id', itemId);
    return fetch('add_to_cart.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
      body: body
    }).then(function(r){ return safeJson(r); });
  }

  function handleAddToCartResponse(data, btn) {
    if(!data) { alert('Неверный ответ сервера'); return; }
    if(data.success) {
      // support both 'cartCount' and 'count'
      var count = (typeof data.cartCount !== 'undefined') ? data.cartCount : data.count;
      if(typeof count !== 'undefined') updateCartCountDisplay(count);
      if(btn) { btn.classList.add('added'); btn.textContent = 'В корзине'; }
    } else {
      alert(data.message || 'Не удалось добавить в корзину');
    }
  }

  function addToCart(itemId, btn) {
    addToCartRequest(itemId).then(function(data){
      handleAddToCartResponse(data, btn);
    }).catch(function(err){
      console.error(err);
      alert('Ошибка сети при добавлении в корзину');
    });
  }

  // Delegated click listener
  document.addEventListener('click', function(e){
    var btn = e.target.closest && e.target.closest('.add-to-cart');
    if(!btn) return;
    e.preventDefault();
    var id = btn.getAttribute('data-id') || btn.dataset.id;
    if(!id) { console.warn('add-to-cart clicked without data-id'); return; }
    addToCart(id, btn);
  }, false);

  // Init on DOM ready
  document.addEventListener('DOMContentLoaded', function(){
    fetchCartCount();
  });
})();