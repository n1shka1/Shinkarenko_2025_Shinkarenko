<?php
require_once 'config.php';

$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$category = isset($_GET['category']) ? (int)$_GET['category'] : 0;

// Получаем список категорий
$categories = [];
try {
    $stmt = $pdo->query("SELECT * FROM categories");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $error = "Ошибка при получении категорий: " . $e->getMessage();
}

// Получаем блюда с учетом поиска и категории
$menuItems = [];
$sql = "SELECT * FROM menu_items WHERE is_available = TRUE";
$params = [];

if(!empty($search)) {
    $sql .= " AND name LIKE ?";
    $params[] = "%$search%";
}

if($category > 0) {
    $sql .= " AND category_id = ?";
    $params[] = $category;
}

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $menuItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    $error = "Ошибка при получении меню: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
<meta property="og:title" content="Red&Black Cafe">
<meta property="og:type" content="website">
<meta property="og:image" content="images/favicon.svg">

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#cc0000">
<meta name="description" content="Red&Black Cafe — онлайн-меню, быстрая корзина и оформление заказа.">
<link rel="icon" href="images/favicon.svg" type="image/svg+xml">
<link rel="manifest" href="site.webmanifest">
<link rel="preload" as="style" href="css/style.css" onload="this.onload=null;this.rel='stylesheet'">
<noscript><link rel="stylesheet" href="css/style.css"></noscript>
<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" referrerpolicy="no-referrer">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Меню - Red&Black Cafe</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/main.js" defer></script>
</head>
<body>
    <header>
        <div class="container header-content">
            <div class="logo">Red<span>&</span>Black</div>
        <?php if (isLoggedIn()): ?>
            <div class="user-greeting">Привет, <?= htmlspecialchars($_SESSION['username']) ?>!</div>
        <?php endif; ?>
            <nav>
    <ul>
        <li><a href="index.php"><i class="fa-solid fa-house" aria-hidden="true"></i> <span>Главная</span></a></li>
        <?php if(!isManagerOrAdmin()): ?>
            <li><a href="menu.php"><i class="fa-solid fa-utensils" aria-hidden="true"></i> <span>Меню</span></a></li>
        <?php endif; ?>
        <?php if(isLoggedIn()): ?>
            <?php if(userHasRole(['admin'])): ?>
                <li><a href="admin.php"><i class="fa-solid fa-user-gear" aria-hidden="true"></i> <span>Админ-панель</span></a></li>
            <?php elseif(userHasRole(['manager'])): ?>
                <li><a href="manager.php"><i class="fa-solid fa-clipboard-list" aria-hidden="true"></i> <span>Менеджер</span></a></li>
            <?php else: ?>
                <li><a href="orders.php"><i class="fa-solid fa-receipt" aria-hidden="true"></i> <span>Мои заказы</span></a></li>
            <?php endif; ?>
            <li><a href="cart.php"><i class="fa-solid fa-cart-shopping" aria-hidden="true"></i> <span>Корзина</span> <span class="cart-count">0</span></a></li>
            <li><a href="logout.php"><i class="fa-solid fa-right-from-bracket" aria-hidden="true"></i> <span>Выйти</span></a></li>
        <?php else: ?>
            <li><a href="login.php"><i class="fa-solid fa-right-to-bracket" aria-hidden="true"></i> <span>Войти</span></a></li>
            <li><a href="register.php"><i class="fa-solid fa-user-plus" aria-hidden="true"></i> <span>Регистрация</span></a></li>
        <?php endif; ?>
    </ul>
</nav>
        </div>
    </header>

    <main class="container">
        <h1>Наше меню</h1>
        
        <?php if(isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
   <div class="search-container">
    <form action="menu.php" method="GET" class="search-form">
        <input type="text" name="search" placeholder="Поиск по меню..." value="<?php echo $search; ?>">
        <button type="submit" class="btn" style="margin-top: 10px; width: 100%;">Поиск</button>
    </form>

    <!-- Отдельная кнопка "Все категории" -->
    <form action="menu.php" method="GET" style="margin-top: 10px;">
        <button type="submit" name="category" value="0" class="btn" style="width: 100%;">Сбросить все фильтры</button>
    </form>

    <!-- Селект категорий -->
    <div class="category-select" style="margin-top: 10px;">
        <form action="menu.php" method="GET">
            <select name="category" onchange="this.form.submit()" class="nice-select">
                <option value="0">Выберите категорию</option>
                <?php foreach($categories as $cat): ?>
                    <option value="<?php echo $cat['id']; ?>" <?php echo $category == $cat['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($cat['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>
</div>
        
        <div class="menu-grid">
            <?php if(empty($menuItems)): ?>
                <p>Ничего не найдено.</p>
            <?php else: ?>
                <?php foreach($menuItems as $item): ?>
                    <div class="menu-item">
                        <img src="<?php echo $item['image_path'] ?: 'images/placeholder.jpg'; ?>" alt="<?php echo $item['name']; ?>" class="menu-item-img">
                        <div class="menu-item-content">
                            <h3 class="menu-item-title"><?php echo $item['name']; ?></h3>
                            <p class="menu-item-desc"><?php echo $item['description']; ?></p>
                            <div class="menu-item-footer">
                                <span class="menu-item-price"><?php echo $item['price']; ?> ₽</span>
                                <?php if(isLoggedIn()): ?>
                                    <button class="btn add-to-cart" data-id="<?php echo $item['id']; ?>">В корзину</button>
                                <?php else: ?>
                                    <a href="login.php" class="btn">Войдите для заказа</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    <?php include 'footer.php'; ?>