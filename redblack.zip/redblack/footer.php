<footer style="background: var(--dark-gray); color: #fff; padding: 40px 20px; margin-top: 50px;">
    <div class="container" style="text-align: center; max-width: 1000px; margin: 0 auto;">
        
        <!-- Логотип -->
        <h2 style="font-size: 28px; margin-bottom: 15px;">Red<span style="color: var(--red);">&</span>Black Cafe</h2>
        
        <!-- Контактная информация -->
        <p style="margin: 5px 0;"><i class="fa-solid fa-location-dot"></i> г. Барнаул, ул. Комсомольский проспект, 100  </p>
        <p style="margin: 5px 0;"><i class="fa-solid fa-phone"></i> +7 (905) 123 12 12</p>
        <p style="margin: 5px 0;"><i class="fa-solid fa-envelope"></i> redblackcafe@mail.ru</p>

        <!-- Социальные сети -->
        <div style="margin: 20px 0;">
            <a href="https://vk.com" target="_blank" style="color: #fff; margin: 0 10px; font-size: 22px;"><i class="fa-brands fa-vk"></i></a>
            <a href="https://t.me" target="_blank" style="color: #fff; margin: 0 10px; font-size: 22px;"><i class="fa-brands fa-telegram"></i></a>
            <a href="https://instagram.com" target="_blank" style="color: #fff; margin: 0 10px; font-size: 22px;"><i class="fa-brands fa-instagram"></i></a>
            <a href="https://facebook.com" target="_blank" style="color: #fff; margin: 0 10px; font-size: 22px;"><i class="fa-brands fa-facebook"></i></a>
        </div>

        <!-- Карта -->
        <div style="margin: 30px 0;">
            <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2244.0273613437633!2d37.61763531593059!3d55.75582698055296!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x46b54a5a6b7d2f9f%3A0x7a64e124b5e8b!2z0JzQvtGB0LrQstCw0YAg0KHQvtCy0LXRgNC90YvQuSDQutGA0LDRgdC40Y8!5e0!3m2!1sru!2sru!4v1693587419089!5m2!1sru!2sru" 
                width="100%" height="250" style="border:0; border-radius: 10px;" allowfullscreen="" loading="lazy">
            </iframe>
        </div>

        <!-- Авторские права -->
        <p style="margin-top: 20px; font-size: 14px; color: #aaa;">
            © <?= date("Y"); ?> Red&Black Cafe. Все права защищены.
        </p>
    </div>
</footer>