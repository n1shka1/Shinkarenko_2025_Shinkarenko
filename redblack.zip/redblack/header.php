<header>
    <div class="container header-content">
        <div class="logo">Red<span>&</span>Black</div>
        <nav>
            <ul>
                <?php if(!isManagerOrAdmin()): ?>

                <?php endif; ?>

                <?php if(isLoggedIn()): ?>
                    <?php if(userHasRole(['admin'])): ?>
                        <li><a href="admin.php"><i class="fa-solid fa-user-gear"></i> <span>Админ-панель</span></a></li>
                    <?php elseif(userHasRole(['manager'])): ?>
                        <li><a href="manager.php"><i class="fa-solid fa-clipboard-list"></i> <span>Менеджер</span></a></li>
                    <?php else: ?>
                        <li><a href="orders.php"><i class="fa-solid fa-receipt"></i> <span>Мои заказы</span></a></li>
                    <?php endif; ?>
                    <li><a href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> <span>Выйти</span></a></li>
                <?php else: ?>
                    <li><a href="login.php"><i class="fa-solid fa-right-to-bracket"></i> <span>Войти</span></a></li>
                    <li><a href="register.php"><i class="fa-solid fa-user-plus"></i> <span>Регистрация</span></a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>
