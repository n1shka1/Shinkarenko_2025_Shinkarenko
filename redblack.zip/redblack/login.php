<?php
require_once 'config.php';

$error = '';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = sanitize($_POST['username']);
    $password = sanitize($_POST['password']);
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['user_role'] = $user['role'];
            
            // Перенаправление в зависимости от роли
            if($user['role'] == 'admin') {
                header("Location: admin.php");
            } elseif($user['role'] == 'manager') {
                header("Location: manager.php");
            } else {
                header("Location: index.php");
            }
            exit();
        } else {
            $error = "Неверное имя пользователя или пароль";
        }
    } catch(PDOException $e) {
        $error = "Ошибка при авторизации: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
<meta property="og:title" content="Red&Black Cafe">
<meta property="og:type" content="website">
<meta property="og:image" content="images/favicon.svg">

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#cc0000">
<meta name="description" content="Red&Black Cafe — онлайн-меню, быстрая корзина и оформление заказа.">
<link rel="icon" href="images/favicon.svg" type="image/svg+xml">
<link rel="manifest" href="site.webmanifest">
<link rel="preload" as="style" href="css/style.css" onload="this.onload=null;this.rel='stylesheet'">
<noscript><link rel="stylesheet" href="css/style.css"></noscript>
<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" referrerpolicy="no-referrer">

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Вход - Red&Black Cafe</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="js/main.js" defer></script>
</head>
<body>
    <header>
        <div class="container header-content">
            <div class="logo">Red<span>&</span>Black</div>
            <nav>
                <ul>
                    <li><a href="index.php"><i class="fa-solid fa-house" aria-hidden="true"></i> <span>Главная</span></a></li>
                    <li><a href="menu.php"><i class="fa-solid fa-utensils" aria-hidden="true"></i> <span>Меню</span></a></li>
                    <?php if(isLoggedIn()): ?>
                        <li><a href="logout.php"><i class="fa-solid fa-right-from-bracket" aria-hidden="true"></i> <span>Выйти</span></a></li>
                    <?php else: ?>
                        <li><a href="login.php"><i class="fa-solid fa-right-to-bracket" aria-hidden="true"></i> <span>Войти</span></a></li>
                        <li><a href="register.php"><i class="fa-solid fa-user-plus" aria-hidden="true"></i> <span>Регистрация</span></a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <main class="container">
        <div class="form-container">
            <h2>Вход в систему</h2>
            
            <?php if($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <form action="login.php" method="POST">
                <div class="form-group">
                    <label for="username">Имя пользователя</label>
                    <input type="text" id="username" name="username" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Пароль</label>
                    <input type="password" id="password" name="password" required>
                </div>
                
                <button type="submit" class="btn btn-block">Войти</button>
            </form>
            
            <p style="text-align: center; margin-top: 20px;">Еще нет аккаунта? <a href="register.php">Зарегистрируйтесь</a></p>
        </div>
    <?php include 'footer.php'; ?>