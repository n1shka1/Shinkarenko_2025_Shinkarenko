<?php
require_once 'config.php'; // подключение к БД и вспомогательных функций

// Проверка авторизации
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Фильтр заказов (активные / неактивные)
$filter = $_GET['filter'] ?? 'active';
if ($filter === 'inactive') {
    $statusCondition = "status IN ('cancelled','paid')";
} else {
    $statusCondition = "status NOT IN ('cancelled','paid')";
}

$orders = [];
try {
    // Получаем заказы пользователя
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? AND $statusCondition ORDER BY order_date DESC");
    $stmt->execute([$_SESSION['user_id']]);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Получаем состав каждого заказа
    foreach ($orders as &$order) {
        $stmtItems = $pdo->prepare("
            SELECT oi.*, mi.name 
            FROM order_items oi 
            JOIN menu_items mi ON oi.menu_item_id = mi.id 
            WHERE oi.order_id = ?
        ");
        $stmtItems->execute([$order['id']]);
        $order['items'] = $stmtItems->fetchAll(PDO::FETCH_ASSOC);
    }
    unset($order);

} catch (PDOException $e) {
    $error = "Ошибка при получении заказов: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
<meta property="og:title" content="Red&Black Cafe">
<meta property="og:type" content="website">
<meta property="og:image" content="images/favicon.svg">

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#cc0000">
<meta name="description" content="Red&Black Cafe — онлайн-меню, быстрая корзина и оформление заказа.">
<link rel="icon" href="images/favicon.svg" type="image/svg+xml">
<link rel="manifest" href="site.webmanifest">
<link rel="preload" as="style" href="css/style.css" onload="this.onload=null;this.rel='stylesheet'">
<noscript><link rel="stylesheet" href="css/style.css"></noscript>
<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" referrerpolicy="no-referrer">

<title>Мои заказы - Red&Black Cafe</title>
<link rel="stylesheet" href="css/style.css">
<script src="js/main.js" defer></script>
</head>
<body>
<header>
    <div class="container header-content">
        <div class="logo">Red<span>&</span>Black</div>
        <?php if (isLoggedIn()): ?>
            <div class="user-greeting">Привет, <?= htmlspecialchars($_SESSION['username']) ?>!</div>
        <?php endif; ?>
        <nav>
            <ul>
                <li><a href="index.php"><i class="fa-solid fa-house" aria-hidden="true"></i> <span>Главная</span></a></li>
                <?php if(!isManagerOrAdmin()): ?>
                    <li><a href="menu.php"><i class="fa-solid fa-utensils" aria-hidden="true"></i> <span>Меню</span></a></li>
                <?php endif; ?>
                <?php if(isLoggedIn()): ?>
                    <?php if(userHasRole(['admin'])): ?>
                        <li><a href="admin.php"><i class="fa-solid fa-user-gear" aria-hidden="true"></i> <span>Админ-панель</span></a></li>
                    <?php elseif(userHasRole(['manager'])): ?>
                        <li><a href="manager.php"><i class="fa-solid fa-clipboard-list" aria-hidden="true"></i> <span>Менеджер</span></a></li>
                    <?php else: ?>
                        <li><a href="orders.php"><i class="fa-solid fa-receipt" aria-hidden="true"></i> <span>Мои заказы</span></a></li>
                    <?php endif; ?>
                    <li><a href="cart.php"><i class="fa-solid fa-cart-shopping" aria-hidden="true"></i> <span>Корзина</span> <span class="cart-count">0</span></a></li>
                    <li><a href="logout.php"><i class="fa-solid fa-right-from-bracket" aria-hidden="true"></i> <span>Выйти</span></a></li>
                <?php else: ?>
                    <li><a href="login.php"><i class="fa-solid fa-right-to-bracket" aria-hidden="true"></i> <span>Войти</span></a></li>
                    <li><a href="register.php"><i class="fa-solid fa-user-plus" aria-hidden="true"></i> <span>Регистрация</span></a></li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</header>

<main class="container">
    <h1>Мои заказы</h1>

    <div class="orders-nav" style="margin-bottom: 20px;">
        <a href="orders.php?filter=active" class="<?= $filter === 'active' ? 'active' : '' ?>">Активные</a> |
        <a href="orders.php?filter=inactive" class="<?= $filter === 'inactive' ? 'active' : '' ?>">Неактивные</a>
    </div>

    <?php if(isset($error)): ?>
        <div class="alert alert-error"><?php echo $error; ?></div>
    <?php endif; ?>

    <?php if(empty($orders)): ?>
        <p>У вас пока нет заказов. <a href="menu.php">Перейти в меню</a></p>
    <?php else: ?>
        <div style="margin-top: 30px;">
            <?php foreach($orders as $order): ?>
                <div style="background-color: var(--dark-gray); padding: 20px; border-radius: 5px; margin-bottom: 20px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 15px;">
                        <div>
                            <h3>Заказ #<?php echo $order['id']; ?></h3>
                            <p>Дата: <?php echo $order['order_date']; ?></p>
                            <p>Статус: 
                                <?php 
                                $statuses = [
                                    'pending' => 'Принят',
                                    'preparing' => 'Готовится',
                                    'out_for_delivery' => 'Передан курьеру',
                                    'delivered' => 'Доставлен',
                                    'paid' => 'Оплачен',
                                    'cancelled' => 'Отменен'
                                ];
                                echo $statuses[$order['status']] ?? $order['status']; 
                                ?>
                            </p>
                            <p>Адрес: <?php echo $order['delivery_address']; ?></p>
                            <p>Телефон: <?php echo $order['phone']; ?></p>
                        </div>
                        <div>
                            <p style="font-weight: bold; font-size: 1.2rem;">Сумма: <?php echo $order['total_amount']; ?> ₽</p>
                        </div>
                    </div>

                    <h4>Состав заказа:</h4>
                    <table style="width: 100%; border-collapse: collapse; margin-top: 10px;">
                        <thead>
                            <tr style="background-color: var(--black);">
                                <th style="padding: 10px; text-align: left;">Блюдо</th>
                                <th style="padding: 10px; text-align: left;">Количество</th>
                                <th style="padding: 10px; text-align: left;">Цена</th>
                                <th style="padding: 10px; text-align: left;">Сумма</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($order['items'] as $item): ?>
                                <tr style="border-bottom: 1px solid var(--black);">
                                    <td style="padding: 10px;"><?php echo $item['name']; ?></td>
                                    <td style="padding: 10px;"><?php echo $item['quantity']; ?></td>
                                    <td style="padding: 10px;"><?php echo $item['price']; ?> ₽</td>
                                    <td style="padding: 10px;"><?php echo $item['price'] * $item['quantity']; ?> ₽</td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</main>

<?php include 'footer.php'; ?>
</body>
</html>
