<?php
require_once 'config.php';
/* RB: role redirect */
if(isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], ['admin','manager'])){
    $dest = ($_SESSION['user_role']==='admin') ? 'admin.php' : 'manager.php';
    header("Location: " . $dest);
    exit();
}


if(!isLoggedIn()) {
    header("Location: login.php");
    exit();
}

// Обработка добавления в корзину
if(isset($_POST['add_to_cart'])) {
    $item_id = (int)$_POST['item_id'];
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
    
    if(!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }
    
    if(isset($_SESSION['cart'][$item_id])) {
        $_SESSION['cart'][$item_id] += $quantity;
    } else {
        $_SESSION['cart'][$item_id] = $quantity;
    }
    
    header("Location: cart.php");
    exit();
}

// Обработка обновления корзины
if(isset($_POST['update_cart'])) {
    foreach($_POST['quantity'] as $item_id => $quantity) {
        $quantity = (int)$quantity;
        if($quantity > 0) {
            $_SESSION['cart'][$item_id] = $quantity;
        } else {
            unset($_SESSION['cart'][$item_id]);
        }
    }
    
    header("Location: cart.php");
    exit();
}

// Обработка удаления из корзины
if(isset($_GET['remove'])) {
    $item_id = (int)$_GET['remove'];
    if(isset($_SESSION['cart'][$item_id])) {
        unset($_SESSION['cart'][$item_id]);
    }
    
    header("Location: cart.php");
    exit();
}

// Обработка оформления заказа
if(isset($_POST['checkout'])) {
    $address = sanitize($_POST['address']);
    $phone = sanitize($_POST['phone']);
    
    if(empty($address) || empty($phone)) {
        $error = "Пожалуйста, заполните все поля";
    } elseif(empty($_SESSION['cart'])) {
        $error = "Ваша корзина пуста";
    } else {
        try {
            $pdo->beginTransaction();
            
            // Создаем заказ
            $total = 0;
            $stmt = $pdo->prepare("INSERT INTO orders (user_id, total_amount, delivery_address, phone) VALUES (?, ?, ?, ?)");
            $stmt->execute([$_SESSION['user_id'], 0, $address, $phone]);
            $order_id = $pdo->lastInsertId();
            
            // Добавляем элементы заказа
            foreach($_SESSION['cart'] as $item_id => $quantity) {
                $stmt = $pdo->prepare("SELECT price FROM menu_items WHERE id = ?");
                $stmt->execute([$item_id]);
                $item = $stmt->fetch();
                
                if($item) {
                    $price = $item['price'];
                    $subtotal = $price * $quantity;
                    $total += $subtotal;
                    
                    $stmt = $pdo->prepare("INSERT INTO order_items (order_id, menu_item_id, quantity, price) VALUES (?, ?, ?, ?)");
                    $stmt->execute([$order_id, $item_id, $quantity, $price]);
                }
            }
            
            // Обновляем общую сумму заказа
            $stmt = $pdo->prepare("UPDATE orders SET total_amount = ? WHERE id = ?");
            $stmt->execute([$total, $order_id]);
            
            $pdo->commit();
            
            // Очищаем корзину
            unset($_SESSION['cart']);
            
            $success = "Заказ успешно оформлен! Номер вашего заказа: #$order_id";
        } catch(PDOException $e) {
            $pdo->rollBack();
            $error = "Ошибка при оформлении заказа: " . $e->getMessage();
        }
    }
}

// Получаем данные о товарах в корзине
$cartItems = [];
$total = 0;

if(!empty($_SESSION['cart'])) {
    $item_ids = array_keys($_SESSION['cart']);
    $placeholders = implode(',', array_fill(0, count($item_ids), '?'));
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM menu_items WHERE id IN ($placeholders)");
        $stmt->execute($item_ids);
        $cartItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Добавляем количество к каждому товару
        foreach($cartItems as &$item) {
            $item['quantity'] = $_SESSION['cart'][$item['id']];
            $item['subtotal'] = $item['price'] * $item['quantity'];
            $total += $item['subtotal'];
        }
        unset($item); // FIX: разорвать ссылку после foreach-by-reference, иначе все элементы станут как последний

    } catch(PDOException $e) {
        $error = "Ошибка при получении данных о товарах: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
	<meta property="og:title" content="Red&Black Cafe">
	<meta property="og:type" content="website">
	<meta property="og:image" content="images/favicon.svg">
	<link rel="icon" href="images/favicon.svg" type="image/svg+xml">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Корзина - Red&Black Cafe</title>
    <link rel="stylesheet" href="css/style.css">

<link rel="preconnect" href="https://cdnjs.cloudflare.com" crossorigin>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" referrerpolicy="no-referrer">
    <script src="js/main.js" defer></script>
</head>
<body>
    <header>
        <div class="container header-content">
            <div class="logo">Red<span>&</span>Black</div>
			<?php if (isLoggedIn()): ?>
            <div class="user-greeting">Привет, <?= htmlspecialchars($_SESSION['username']) ?>!</div>
        <?php endif; ?>
            <nav>
    <ul>
        <li><a href="index.php"><i class="fa-solid fa-house" aria-hidden="true"></i> <span>Главная</span></a></li>
        <?php if(!isManagerOrAdmin()): ?>
            <li><a href="menu.php"><i class="fa-solid fa-utensils" aria-hidden="true"></i> <span>Меню</span></a></li>
        <?php endif; ?>
        <?php if(isLoggedIn()): ?>
            <?php if(userHasRole(['admin'])): ?>
                <li><a href="admin.php"><i class="fa-solid fa-user-gear" aria-hidden="true"></i> <span>Админ-панель</span></a></li>
            <?php elseif(userHasRole(['manager'])): ?>
                <li><a href="manager.php"><i class="fa-solid fa-clipboard-list" aria-hidden="true"></i> <span>Менеджер</span></a></li>
            <?php else: ?>
                <li><a href="orders.php"><i class="fa-solid fa-receipt" aria-hidden="true"></i> <span>Мои заказы</span></a></li>
            <?php endif; ?>
            <li><a href="cart.php"><i class="fa-solid fa-cart-shopping" aria-hidden="true"></i> <span>Корзина</span> <span class="cart-count">0</span></a></li>
            <li><a href="logout.php"><i class="fa-solid fa-right-from-bracket" aria-hidden="true"></i> <span>Выйти</span></a></li>
        <?php else: ?>
            <li><a href="login.php"><i class="fa-solid fa-right-to-bracket" aria-hidden="true"></i> <span>Войти</span></a></li>
            <li><a href="register.php"><i class="fa-solid fa-user-plus" aria-hidden="true"></i> <span>Регистрация</span></a></li>
        <?php endif; ?>
    </ul>
</nav>
        </div>
    </header>

    <main class="container">
        <h1>Ваша корзина</h1>
        
        <?php if(isset($error)): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if(isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <?php if(empty($cartItems)): ?>
            <p>Ваша корзина пуста. <a href="menu.php">Перейти в меню</a></p>
        <?php else: ?>
            <form action="cart.php" method="POST">
                <div class="cart-container">
                    <?php foreach($cartItems as $item): ?>
                        <div class="cart-item">
                            <div class="cart-item-info">
                                <h3><?php echo $item['name']; ?></h3>
                                <p data-price="<?php echo $item['price']; ?>"><?php echo $item['price']; ?> ₽ за шт.</p>
                            </div>
                            <div class="cart-item-controls">
                                <a href="cart.php?remove=<?php echo $item['id']; ?>" class="btn" style="background-color: var(--dark-gray);">×</a>
                                <input type="number" name="quantity[<?php echo $item['id']; ?>]" value="<?php echo $item['quantity']; ?>" min="1">
                                <span class="item-subtotal" data-item-id="<?php echo $item['id']; ?>"><?php echo $item['subtotal']; ?> ₽</span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    
                    <div class="cart-total">
                        Итого: <?php echo $total; ?> ₽
                    </div>
                    
                    <button type="submit" name="update_cart" class="btn" style="margin-top: 20px;">Обновить корзину</button>
                </div>
                
                <div class="form-container" style="margin-top: 30px;">
                    <h2>Оформление заказа</h2>
                    <div class="form-group">
                        <label for="address">Адрес доставки</label>
                        <input type="text" id="address" name="address" placeholder="Улица, дом, подъезд, этаж, кв." >
                        <small class="form-hint">Например: ул. Ленина, д.10, подъезд 2, 3 этаж</small>
                    </div>
                    <div class="form-group">
                        <label for="phone">Телефон</label>
                        <input type="text" id="phone" name="phone" placeholder="+7 (___) ___-__-__" >
                        <small class="form-hint">Введите номер в формате +7 (900) 000-00-00</small>
                    </div>
                    <div class="form-group">
                        <label for="notes">Дополнительные пожелания</label>
                        <textarea id="notes" name="notes" placeholder="Например: без лука, сделать менее острым" rows="3"></textarea>
                    </div>
                    <button type="submit" name="checkout" class="btn btn-block">Оформить заказ</button>
                </div>
            </form>
        <?php endif; ?>
    <?php include 'footer.php'; ?>